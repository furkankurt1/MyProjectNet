
CREATE VIEW INFORMATION_SCHEMA.SEQUENCES
AS
SELECT
      DB_NAME() AS SEQUENCE_CATALOG,
      SCHEMA_NAME(s.schema_id) AS SEQUENCE_SCHEMA,
      s.name AS SEQUENCE_NAME,
      ISNULL(TYPE_NAME(s.system_type_id), t.name) AS DATA_TYPE,
      s.precision AS NUMERIC_PRECISION,
      convert(smallint, CASE  -- int/money/decimal/numeric
            WHEN s.system_type_id IN (48, 52, 56, 60, 106, 108, 122, 127) THEN 10
            WHEN s.system_type_id IN (59, 62) THEN 2
            END) AS NUMERIC_PRECISION_RADIX,    -- real/float
      ODBCSCALE(s.system_type_id, s.scale) AS NUMERIC_SCALE,
      s.start_value AS START_VALUE,
      s.minimum_value AS MINIMUM_VALUE,
      s.maximum_value AS MAXIMUM_VALUE,
      s.increment AS INCREMENT,
      s.is_cycling AS CYCLE_OPTION,
      t.name AS DECLARED_DATA_TYPE,
      t.precision AS DECLARED_NUMERIC_PRECISION,
      t.scale AS DECLARED_NUMERIC_SCALE
FROM
      sys.sequences as s
      JOIN sys.types t ON s.user_type_id = t.user_type_id;
go

