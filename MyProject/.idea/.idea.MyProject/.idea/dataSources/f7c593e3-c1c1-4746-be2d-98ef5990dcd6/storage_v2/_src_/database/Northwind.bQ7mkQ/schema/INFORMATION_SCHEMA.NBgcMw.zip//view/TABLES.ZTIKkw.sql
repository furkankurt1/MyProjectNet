CREATE VIEW INFORMATION_SCHEMA.TABLES
AS 
SELECT
	DB_NAME()			AS TABLE_CATALOG,
	s.name				AS TABLE_SCHEMA,
	o.name				AS TABLE_NAME,
	CASE o.type
		WHEN 'U' THEN 'BASE TABLE'
		WHEN 'V' THEN 'VIEW'
	END				AS TABLE_TYPE
FROM
	sys.objects o LEFT JOIN sys.schemas s
	ON s.schema_id = o.schema_id
WHERE
	o.type IN ('U', 'V')
go

