CREATE VIEW INFORMATION_SCHEMA.VIEW_COLUMN_USAGE
AS
SELECT
	DB_NAME()					AS VIEW_CATALOG,
	SCHEMA_NAME(v.schema_id)	AS VIEW_SCHEMA,
	v.name						AS VIEW_NAME,
	DB_NAME()					AS TABLE_CATALOG,
	SCHEMA_NAME(t.schema_id)	AS TABLE_SCHEMA,
	t.name						AS TABLE_NAME,
	c.name						AS COLUMN_NAME
FROM
	sys.views v JOIN sys.sql_dependencies d ON d.object_id = v.object_id
	JOIN sys.objects t ON t.object_id = d.referenced_major_id
	JOIN sys.columns c ON c.object_id = d.referenced_major_id
		AND c.column_id = d.referenced_minor_id
WHERE
	d.class < 2
go

